#pragma once
#include <string>

const int majorTypeCount = 3;
enum class CourseTypeEnum { NETWORK, SECURITY, SOFTWARE};
static std::string courseTypeStrings[majorTypeCount] = { "NETWORK","SECURITY","SOFTWARE"};
