#include <string>
#include "networkStudent.h"
#include "degree.h"
#include <iostream>

using namespace std;

networkStudent::networkStudent() :Student()
{
}

networkStudent::networkStudent(string studentID, string firstName, string lastName, string emailAddress, int ageNow, int days[3], CourseTypeEnum majorType) : Student(studentID, firstName, lastName, emailAddress, ageNow, days)
{
	this->majorType = CourseTypeEnum::NETWORK;
}


void networkStudent::print()
{
	CourseTypeEnum ct = this->getDegreeProgram();
	this->Student::print();
	cout << courseTypeStrings[(int)ct] << endl;
}

CourseTypeEnum networkStudent::getDegreeProgram()
{
	CourseTypeEnum ct = this->majorType;
	return ct;
}

networkStudent::~networkStudent()
{
	Student::~Student();
}
