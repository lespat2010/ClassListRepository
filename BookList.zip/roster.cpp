#include <string>
#include "student.h"
#include "networkStudent.h"
#include "securityStudent.h"
#include "softwareStudent.h"
#include "roster.h"
#include "degree.h"
#include <iostream>
#pragma once

using namespace std;

Roster::Roster()
{
    this->capacity = 0;
    this->lastIndex = -1; //means array is empty
    this->classRosterArray = nullptr;
}

Roster::Roster(int capacity)//set max capacity for student roster
{
    this->capacity = capacity;
    this->lastIndex = -1; //means array is empty
    this->classRosterArray = new Student*[capacity];
}

int Roster::ParseAddStudents(string row)//parses student row string and determines values
{
    if (lastIndex < capacity)
    {
        lastIndex++;
      
        size_t rhs = row.find(",");
        string studentIdent = row.substr(0, rhs);

        size_t lhs = rhs + 1;
        rhs = row.find(",", lhs);
        string firstN = row.substr(lhs, rhs - lhs);

        lhs = rhs + 1;
        rhs = row.find(",", lhs);
        string lastN = row.substr(lhs, rhs - lhs);

        lhs = rhs + 1;
        rhs = row.find(",", lhs);
        string eAddr = row.substr(lhs, rhs - lhs);

        lhs = rhs + 1;
        rhs = row.find(",", lhs);
        int nowAge = stoi(row.substr(lhs, rhs - lhs));

        lhs = rhs + 1;
        rhs = row.find(",", lhs);
        int days1 = stoi(row.substr(lhs, rhs - lhs));

        lhs = rhs + 1;
        rhs = row.find(",", lhs);
        int days2 = stoi(row.substr(lhs, rhs - lhs));

        lhs = rhs + 1;
        rhs = row.find(",", lhs);
        int days3 = stoi(row.substr(lhs, rhs - lhs));

        lhs = rhs + 1;
        rhs = row.find("\0", lhs);
        string mainProgram = row.substr(lhs, row.length() - lhs);
                
        CourseTypeEnum theCourseType{};
        if (mainProgram == "SOFTWARE") {

            theCourseType = CourseTypeEnum::SOFTWARE;
        }
        else if (mainProgram == "NETWORK") {
            theCourseType = CourseTypeEnum::NETWORK;
        }
        else if (mainProgram == "SECURITY") {
            theCourseType = CourseTypeEnum::SECURITY;
        }
        add(studentIdent, firstN, lastN, eAddr, nowAge, days1, days2, days3, theCourseType);
    }
    return 0;
}

void Roster::printAll()
{
    for (int i = 0; i <= this->lastIndex; i++)(this->classRosterArray[i]->print());
}

Roster::~Roster()//destructor
{
    for (int i = 0; i <= lastIndex; i++)
    {
        delete this->classRosterArray[i];
    }
    delete classRosterArray;
}

Student* Roster::getStudentAt(int index)
{
    return classRosterArray[index];
}

void Roster::remove(string sID)
{
    bool found = false;
    for (int i = 0; i <= lastIndex; i++)
    {
        if (this->classRosterArray[i]->getStudentID() == sID)
        {
            found = true;
            delete this->classRosterArray[i];
            this->classRosterArray[i] = this->classRosterArray[lastIndex];
            lastIndex--;
        }
    }
    if (!found)cout << "A STUDENT WITH " << sID << " WAS NOT FOUND." << endl;
    
    if (found)
    {
        cout << "Student successfully removed" << endl;
        this->printAll();
        this->numberStudents--;
    }

}

void Roster::add(string studentID, string firstName, string lastName, string emailAddress, int ageNow, int day1, int day2, int day3, CourseTypeEnum majorType)
{
    int daysList[Student::daysCount];
    daysList[0] = day1;
    daysList[1] = day2;
    daysList[2] = day3;

    if (majorType == CourseTypeEnum::SOFTWARE) classRosterArray[lastIndex] = new softwareStudent(studentID, firstName, lastName, emailAddress, ageNow, daysList, majorType);
    else if (majorType == CourseTypeEnum::NETWORK)classRosterArray[lastIndex] = new networkStudent(studentID, firstName, lastName, emailAddress, ageNow, daysList, majorType);
    else if (majorType == CourseTypeEnum::SECURITY)classRosterArray[lastIndex] = new securityStudent(studentID, firstName, lastName, emailAddress, ageNow, daysList, majorType);
}


void Roster::printDaysInCourse(string sID)
{
    for (int i = 0; i <= lastIndex; i++)
    {
        if (this->classRosterArray[i]->getStudentID() == sID)
        {
            int* ave = classRosterArray[i]->getDaysCourses();
            cout << "Average days in courses for student " << sID << " is " << ((double(ave[0]) + double(ave[1]) + double(ave[2])) / 3) << endl;
        }
    }
}

void Roster::printByDegreeProgram(CourseTypeEnum majorType)
{
    for (int i = 0; i <= lastIndex; i++)
    {
         if (this->classRosterArray[i]->getDegreeProgram() == majorType) this->classRosterArray[i]->print();
    }
}

void Roster::printInvalidEmails()
{
    cout << "Displaying invalid emails for students" << endl;
    bool atSymbol = false;
    bool periodSymbol = false;
    bool hasSpace = false;

    for (int i = 0; i <= lastIndex; i++)
    {
        atSymbol = false;
        periodSymbol = false;
        hasSpace = false;
        string sEmail = classRosterArray[i]->getEmailAddr();
        for (int a = 0; a < sEmail.size(); a++)
        {
            if (sEmail.at(a) == '@')
            {
                atSymbol = true;
            }
            if (sEmail.at(a) == '.')
            {
                periodSymbol = true;
            }
            if (sEmail.at(a) == ' ')
            {
                hasSpace = true;
            }
        }
        if (!atSymbol) cout << "Student with ID " << classRosterArray[i]->getStudentID() << " has invalid email address of " << sEmail << endl;
        else if (!periodSymbol) cout << "Student with ID " << classRosterArray[i]->getStudentID() << " has invalid email address of " << sEmail << endl;
        else if (hasSpace) cout << "Student with ID " << classRosterArray[i]->getStudentID() << " has invalid email address of " << sEmail << endl;
    }
}

int Roster::getNumberStudents()
{
    return this->numberStudents;
}

void Roster::setNumberStudents(int numberStudents)
{
    this->numberStudents = numberStudents;
}



void main()
{
    //student string
    const string studentData[5] =
    { "A1,John,Smith,John1989@gm ail.com,20,30,35,40,SECURITY",
    "A2,Suzan,Erickson,Erickson_1990@gmailcom,19,50,30,40,NETWORK",
    "A3,Jack,Napoli,The_lawyer99yahoo.com,19,20,40,33,SOFTWARE",
    "A4,Erin,Black,Erin.black@comcast.net,22,50,58,40,SECURITY",
    "A5,Fake,User,FakeUser@FakeUniversity.edu,43,9,15,8,SOFTWARE" };

    //class roster
    Roster* classRoster = new Roster(Roster::numStudents);
    cout << "Parsing data and adding students" << endl;
    for (int i = 0; i < classRoster->getNumberStudents(); i++)
    {
        classRoster->ParseAddStudents(studentData[i]);//parse each line and add student to class roster
    }
    cout << "DONE adding students" << endl;
    cout << "Display all students" << endl;
    //Print All students after adding
    classRoster->printAll();
    //Pring Invalid emails
    cout << "Find students with invalid email addresses" << endl;
    classRoster->printInvalidEmails();
    //Pring average days in course
    cout << "Print average days in course for all students" << endl;
    for (int i = 0; i < classRoster->getNumberStudents(); i++)
    {
        classRoster->printDaysInCourse(classRoster->getStudentAt(i)->getStudentID());
    }
    //Print by type of degree: Software
    cout << "Print by degree type of SOFTWARE" << endl;
    classRoster->printByDegreeProgram(CourseTypeEnum::SOFTWARE);

    //Remove student A3
    cout << "Remove student A3" << endl;
    classRoster->remove("A3");

    //Attempt to remove student A3 again    
    cout << "Try delete A3 student again" << endl;
    classRoster->remove("A3");

    //Destructor
    delete classRoster;
}


