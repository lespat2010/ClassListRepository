#pragma once
#include "student.h"


class Roster {
public:
	static const int numStudents = 5;
	Roster();
	Roster(int capacity);
	Student* getStudentAt(int index);
	int ParseAddStudents(string row);//parses then adds to class roster
	void printAll();
	~Roster();
	void remove(string sID);
	void add(string studentID, string firstName, string lastName, string emailAddress, int ageNow, int day1, int day2, int day3, CourseTypeEnum majorType);
	void printDaysInCourse(string sID);
	void printByDegreeProgram(CourseTypeEnum majorType);
	void printInvalidEmails();
	int getNumberStudents();
	void setNumberStudents(int numberStudents);
private:
	int numberStudents = numStudents;
	Student* classRoster[numStudents];
	int currentStudentIndex = -1;
	int lastIndex; //last index of student in roster
	int capacity; //mnaximu size of class roster
	Student** classRosterArray; //an array of pointers to students
	
};
