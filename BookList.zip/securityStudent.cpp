#include <string>
#include "securityStudent.h"
#include "degree.h"
#include <iostream>

using namespace std;

securityStudent::securityStudent() :Student()
{
}

securityStudent::securityStudent(string studentID, string firstName, string lastName, string emailAddress, int ageNow, int days[3], CourseTypeEnum majorType) : Student(studentID, firstName, lastName, emailAddress, ageNow, days)
{
	this->majorType = CourseTypeEnum::SECURITY;
}


void securityStudent::print()
{
	CourseTypeEnum ct = this->getDegreeProgram();
	this->Student::print();
	cout << courseTypeStrings[(int)ct] << endl;
}

CourseTypeEnum securityStudent::getDegreeProgram()
{
	CourseTypeEnum ct = this->majorType;
	return ct;
}

securityStudent::~securityStudent()
{
	Student::~Student();
}
