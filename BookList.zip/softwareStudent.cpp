#include <string>
#include "softwareStudent.h"
#include "degree.h"
#include <iostream>

using namespace std;



softwareStudent::softwareStudent() :Student()
{
	majorType = CourseTypeEnum::SOFTWARE;
}


softwareStudent::softwareStudent(string studentID, string firstName, string lastName, string emailAddress, int ageNow, int days[3], CourseTypeEnum majorType) : Student(studentID, firstName, lastName, emailAddress,ageNow, days)
{
	this->majorType = CourseTypeEnum::SOFTWARE;
}



void softwareStudent::print() 
{
	CourseTypeEnum ct = this->getDegreeProgram();
	this->Student::print();
	cout << courseTypeStrings[(int)ct] << endl;
}

CourseTypeEnum softwareStudent::getDegreeProgram()
{
	CourseTypeEnum ct = this->majorType;
	return ct;
}

softwareStudent::~softwareStudent()
{
	Student::~Student();
}

