#include <string>
#include "student.h"
#include "degree.h"
#pragma once

using namespace std;

class softwareStudent : public Student
{
public:
	softwareStudent();
	softwareStudent(string studentID, string firstName, string lastName, string emailAddress, int ageNow, int days[3], CourseTypeEnum majorType);
	void print();
	CourseTypeEnum getDegreeProgram();
	~softwareStudent();
private:
	CourseTypeEnum majorType;

};

