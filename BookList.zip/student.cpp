#include <iostream>
#include <string>
#include "student.h"
using std::cout;
using std::endl;

Student::Student()
{
	this->studentID = "";
	this->firstName = "";
	this->lastName = "";
	this->emailAddress = "";
	this->ageNow = 0;
	for (int i = 0; i < majorTypeCount; i++)this->days[i] = 0;
}

Student::Student(string studentID, string firstName, string lastName, string emailAddress, int ageNow, int days[])//the full constructor
{
	this->studentID = studentID;
	this->firstName = firstName;
	this->lastName = lastName;
	this->emailAddress = emailAddress;
	this->ageNow = ageNow;
	for (int i = 0; i < majorTypeCount; i++)this->days[i] = days[i];
}

void Student::PrintStudent()
{
	cout << this->studentID << "\t" << this->firstName << "\t";
	cout << this->lastName << "\t\t" << this->emailAddress; 
	cout << "\t\t" << this->ageNow << "\t" << this->days[0]; 
	cout << "," << this->days[1] << ",";
	cout << this->days[2] << "\t";
	//cout << courseTypeStrings[(int)this->majorType] << endl;
	
	//cout << this->getDegreeProgram() << endl;

}

void Student::print()
{
	int* dayList = this->getDaysCourses();

	cout << this->getStudentID() << "\t";
	cout << this->getFirstName() << "\t";
	cout << this->getLastName() << "\t";
	cout << this->getEmailAddr();
	cout << "\t" << this->getAgeNow() << "\t";
	cout << dayList[0];
	cout << "," << dayList[1] << ",";
	cout << dayList[2] << "\t";

}


Student::~Student()
{

}

string Student::getFirstName()
{
	return firstName;
}

string Student::getStudentID()
{
	return studentID;
}

 string Student::getLastName()
{
	return lastName;
}

string Student::getEmailAddr()
{
	return emailAddress;
}

int Student::getAgeNow()
{
	return ageNow;
}

 int* Student::getDaysCourses()
{
	return days;
}

//string Student::getDaysCoursesString()
//{
//	
//	//return this->days[0] + "," + this->days[1] + "," + this->days[2];
//	//return this->days[0] +','+days[1]+','+days[2];
//	return "1,2,3";
//}

void Student::setFirstName(string firstName)
{
	this->firstName = firstName;
}

void Student::setLastName(string lastName)
{
	this->lastName = lastName;
}

void Student::setStudentID(string studentID)
{
	this->studentID = studentID;
}

void Student::setEmailAddr(string emailAddress)
{
	this->emailAddress = emailAddress;
}

void Student::setAgeNow(int ageNow)
{
	this->ageNow = ageNow;
}

void Student::setDaysCourses(int days[])
{
	for (int i = 0; i < majorTypeCount; i++)this->days[i] = days[i];
}


