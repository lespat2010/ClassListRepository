#pragma once
#include <string>
#include "degree.h"
using std::string;

class Student {
public:
	Student();
	Student(string studentID, string firstName, string lastName, string emailAddress, int ageNow, int days[3]);
	void PrintStudent();
	virtual void print() = 0;
	virtual CourseTypeEnum getDegreeProgram() = 0;
	~Student();
	string getFirstName();
	string getStudentID();
	string getLastName();
	string getEmailAddr();
	int getAgeNow();
	int* getDaysCourses();
	const static int daysCount = 3;
	void setFirstName(string firstName);
	void setLastName(string lastName);
	void setStudentID(string studentID);
	void setEmailAddr(string emailAddress);
	void setAgeNow(int ageNow);
	void setDaysCourses(int days[]);
private:
	string studentID;
	string firstName;
	string lastName;
	string emailAddress;
	int ageNow;
	int days[3];

};

